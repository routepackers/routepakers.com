export const ServicesData = [
    {
        "title": "Open Carriers",
        "description": "Open carriers are large trucks or trailers designed to transport multiple vehicles"
    },
    {
        "title": "Enclosed Carriers",
        "description": "Enclosed carriers are similar to open carriers, but they have an enclosed structure"
    },
]