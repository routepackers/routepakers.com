/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["panel.routepackers.com"],
  },
};

module.exports = nextConfig;
