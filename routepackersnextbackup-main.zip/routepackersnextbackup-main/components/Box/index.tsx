import React from 'react'

const Box = () => {
  return (
    <div className='bg-gray-rp rounded-'>
      
    </div>
  )
}

export default Box
